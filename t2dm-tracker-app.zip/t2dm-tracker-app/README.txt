# T2DM Tracker (Static App)

A single-file web app for tracking patient info, blood sugar (up to 4/day), medications, weight, food diary, and local-only messages. Everything is stored in `localStorage` (no servers).

## Publish

### GitHub Pages
1. Create a repo (e.g., `t2dm-tracker`).
2. Upload the files in this folder.
3. Settings → Pages → Branch: `main` and Folder: `/ (root)`
4. Your URL will be: `https://<your-username>.github.io/<repo-name>/`

### Netlify
- https://app.netlify.com/drop then drag this folder. Done.

### Vercel
- Import the repo → deploy (no build step required).

